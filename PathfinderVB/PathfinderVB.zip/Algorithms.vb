﻿Namespace Pathfinder
    Public Enum Algorithms
        Dijkstra
        Optimistic
        AStar
    End Enum
End Namespace
